#!/bin/sh
sudo apt-get update && npm i querystring && npm i url && npm i request && npm i crypto && npm i net && npm i fs && npm i cloudscraper && npm i atomic-sleep && npm i puppeteer-extra && npm i puppeteer-extra-plugin-stealth && npm i randomstring && npm i fake-useragent && npm i request && npm i fake-useragent && npm i random-useragent && echo '>>>>>>>>>>>>>>> DONE'
